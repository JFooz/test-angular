import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatToolbarModule} from '@angular/material/toolbar';
import { RouterModule, Routes } from '@angular/router';
import {MatListModule} from '@angular/material/list';
import {MatFormFieldModule} from '@angular/material/form-field';

import { AppComponent } from './app.component';
import { AccueilComponent } from './accueil/accueil.component';
import { MenuComponent } from './menu/menu.component';
import { TestComponent } from './test/test.component';
import { FormulaireComponent } from './formulaire/formulaire.component';

const routes: Routes = [
  ​{ path: 'acceuil', component: AccueilComponent},
  { path: 'test', component: TestComponent},
  { path: 'formulaire', component: FormulaireComponent}
];
@NgModule({
  declarations: [
    AppComponent,
    AccueilComponent,
    MenuComponent,
    TestComponent,
    FormulaireComponent
  ],
  imports: [
    MatSidenavModule,
    BrowserModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    RouterModule,
    RouterModule.forRoot(routes),
    MatListModule,
    MatFormFieldModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
